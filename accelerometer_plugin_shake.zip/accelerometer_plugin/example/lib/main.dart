import 'package:flutter/material.dart';
import 'package:accelerometer_plugin/accelerometer_plugin.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ShakeDetectionScreen(),
    );
  }
}

class ShakeDetectionScreen extends StatefulWidget {
  @override
  _ShakeDetectionScreenState createState() => _ShakeDetectionScreenState();
}

class _ShakeDetectionScreenState extends State<ShakeDetectionScreen> {
  String _shakeStatus = "No Shake Detected";

  @override
  void initState() {
    super.initState();
    AccelerometerPlugin.sensorStream.listen((event) {
      if (event is String && event == "Shake detected!") {
        setState(() {
          _shakeStatus = "Shake Detected!";
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shake Detection')),
      body: Center(
        child: Text(
          _shakeStatus,
          style: TextStyle(fontSize: 24, color: Colors.blueAccent),
        ),
      ),
    );
  }
}
