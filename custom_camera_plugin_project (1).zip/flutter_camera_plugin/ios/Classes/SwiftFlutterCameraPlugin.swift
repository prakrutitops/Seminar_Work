
import Flutter
import UIKit

public class SwiftFlutterCameraPlugin: NSObject, FlutterPlugin {
    public static func register(with registrar: FlutterPluginRegistrar) {
        let channel = FlutterMethodChannel(name: "flutter_camera_plugin", binaryMessenger: registrar.messenger())
        let instance = SwiftFlutterCameraPlugin()
        registrar.addMethodCallDelegate(instance, channel: channel)
    }

    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        if call.method == "openCamera" {
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                let picker = UIImagePickerController()
                picker.sourceType = .camera
                if let controller = UIApplication.shared.keyWindow?.rootViewController {
                    controller.present(picker, animated: true, completion: nil)
                }
                result("Camera opened")
            } else {
                result(FlutterError(code: "UNAVAILABLE", message: "Camera not available", details: nil))
            }
        } else {
            result(FlutterMethodNotImplemented)
        }
    }
}
        