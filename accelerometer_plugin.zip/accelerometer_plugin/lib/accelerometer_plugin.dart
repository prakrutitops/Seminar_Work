import 'dart:async';
import 'package:flutter/services.dart';

class AccelerometerPlugin {
  static const EventChannel _eventChannel =
      EventChannel('accelerometer_plugin');

  static Stream<Map<String, double>>? _sensorStream;

  static Stream<Map<String, double>> get sensorStream {
    _sensorStream ??= _eventChannel.receiveBroadcastStream().map((event) {
      final data = Map<String, double>.from(event as Map);
      return {
        'x': data['x'] ?? 0.0,
        'y': data['y'] ?? 0.0,
        'z': data['z'] ?? 0.0,
      };
    });
    return _sensorStream!;
  }
}
