import 'package:flutter/material.dart';
import 'package:accelerometer_plugin/accelerometer_plugin.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AccelerometerScreen(),
    );
  }
}

class AccelerometerScreen extends StatefulWidget {
  @override
  _AccelerometerScreenState createState() => _AccelerometerScreenState();
}

class _AccelerometerScreenState extends State<AccelerometerScreen> {
  Map<String, double>? _accelerometerValues;

  @override
  void initState() {
    super.initState();
    AccelerometerPlugin.sensorStream.listen((event) {
      setState(() {
        _accelerometerValues = event;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final accelerometer = _accelerometerValues ?? {'x': 0.0, 'y': 0.0, 'z': 0.0};
    return Scaffold(
      appBar: AppBar(title: const Text('Accelerometer Plugin Example')),
      body: Center(
        child: Text(
          'X: ${accelerometer['x']}, Y: ${accelerometer['y']}, Z: ${accelerometer['z']}',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
